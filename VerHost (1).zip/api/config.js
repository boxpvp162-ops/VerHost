
export const SUPABASE_URL = "https://YOUR_PROJECT.supabase.co";
export const SUPABASE_KEY = "YOUR_PUBLIC_ANON_KEY";
export const JWT_SECRET = "CHANGE_ME";
